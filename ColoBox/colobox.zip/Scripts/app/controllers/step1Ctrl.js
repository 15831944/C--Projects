﻿define(['app/renderer'], function (renderer) {
    function init(app) {
        app.controller('step1Ctrl', function ($scope, coloService) {
            $scope.showGetLayers = 'hidden';
            $scope.showLayersList = 'hidden';
            $scope.getFile = function() {
                coloService.getServerFiles({
                    success: function (arg) {
                        $scope.$apply(function () { $scope.existingFiles = arg.files });
                    },
                    error: function (err) {

                    }
                });
            }
                
            $scope.$watch('selectedFile', function () {
                if ($scope.selectedFile) {
                    $scope.showGetLayers = 'visible';
                }
            });

            $scope.$watch('selectedLayer', function () {
                if (!$scope.selectedLayer) {
                    return;
                }

                $('#svgid').empty();
                var fileName = $scope.selectedFile.replace('.dxf','');
                var data = {
                    FileName: fileName,
                    StaticLayers: [{ Name: $scope.selectedLayer, IsUniverse: true }]
                };

                $.ajax({
                    url: 'Colo/GetUniverse',
                    data: JSON.stringify(data),
                    type: 'POST',
                    contentType: 'application/json; charset=utf-8',
                    success: function (context) {
                        renderer.Render(context);
                    }
                });
            });

            $scope.GetLayers = function () {
                coloService.getLayers($scope.selectedFile,{
                    success: function (data) {
                        $scope.$apply(function () {
                            $scope.layers = data.layers;
                            $scope.showLayersList = 'visibile';
                        });

                    },
                    error: function (err) {

                    }
                });
            }
            $scope.getFile();
        });
    }


    return {
        init: init
    }
});